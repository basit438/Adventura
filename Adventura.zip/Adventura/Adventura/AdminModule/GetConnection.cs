﻿namespace Adventura.AdminModule
{
    internal class GetConnection : Getconnection
    {
    }
}